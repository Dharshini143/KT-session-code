import java.util.Scanner;

public class Highmark {
private static Scanner value;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int Maths,Physics,Chemistry;
		float Average;
	    value=new Scanner(System.in);
	    
	    
	    //get details
		System.out.println("Enter the Mark Details\n 1.Maths=");	
		Maths=value.nextInt();
		System.out.println("\n 2.Physics=");
		Physics=value.nextInt();
		System.out.println("\n 3.Chemistry=");
		Chemistry=value.nextInt();
		
		//total and average calculations
		int Total=Maths+Physics+Chemistry;
		Average=Total/3;
				
		//making choice using switch case
		
		System.out.println("Select your choice(number) to see details\n 1.Maths Mark\n2.Physics Mark\n3.Chemistry Mark\n4.Total Mark\n5.Average Mark in %\n6.Highest Mark\n");
		int choice=value.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println(Maths);
			break;
		case 2:
			System.out.println(Physics);
			break;
		case 3:
			System.out.println(Chemistry);
			break;
		case 4:
			System.out.println(Total);
			break;
		case 5:
			System.out.println(Average+"%");
			break;
		case 6:
			if(Maths>Physics&&Maths>Chemistry)
			{
				System.out.printf("Highest mark is Maths=");
				System.out.println(Maths);	
			}
			else if(Physics>Chemistry&&Physics>Maths)
			{
				System.out.printf("Highest mark is physics=");	
				System.out.println(Physics);
			}
			else
			{
				System.out.printf("Highest mark is chemistry=");
				System.out.println(Chemistry);
			}
			break;
		default:
			System.out.printf(" Mark Details\n 1.Maths=");
			System.out.println(Maths);
			System.out.printf(" \n2.Physics=");
			System.out.println(Physics);
			System.out.printf(" \n 3.Chemistry=");
			System.out.println(Chemistry);
			System.out.printf(" \n 4.Total=",+Total);
			System.out.println(Total);
			System.out.printf("\n 5.Average=",+Average);
			System.out.println(Average);
			break;
		}
		
		
		
		

	}

}
